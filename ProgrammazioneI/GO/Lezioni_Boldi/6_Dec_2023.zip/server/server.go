package main

import (
  "fmt"
  "net/http"
  "image"
  "image/png"
  "math"
  "strconv"
  "github.com/holizz/terrapin"
)

func pippoPage(w http.ResponseWriter, r *http.Request) {
  w.Write([]byte(`
          <!doctype html>
            <title>Pippo</title>
            <h1>Pippo</h1>

            <p>Ciao sono Pippo!

            <p><img src="https://cialdecaffecapsule.files.wordpress.com/2013/01/elefante.jpg?w=240">`))
}

func plutoPage(w http.ResponseWriter, r *http.Request) {
  w.Write([]byte(`
          <!doctype html>
            <title>Pluto</title>
            <h1>Pluto</h1>

            <p>Ciao sono Pluto!

            <p><img src="http://localhost:3000/nostraimmagine.png">`))
}

func imgPage(w http.ResponseWriter, r *http.Request) {
//  f, _ := os.Open("/Users/boldi/Desktop/Progr/paolo.png")
//  image, _ := png.Decode(f)
  image := image.NewRGBA(image.Rect(0, 0, 500, 500))
  t := terrapin.NewTerrapin(image, terrapin.Position{250.0, 250.0})
  t.Forward(100)
  t.Right(math.Pi/2)
  t.Forward(100)
  t.Right(math.Pi/2 + math.Pi/4)
  t.Forward(math.Sqrt(100*100+100*100))
  png.Encode(w, image)
}

/* Questa funzione usa la tartaruga t per disegnare una curva di koch
   di livello dato, con segmenti di lunghezza lung */
func koch(t *terrapin.Terrapin, lung float64, livello int) {
  if livello == 0 {
    t.Forward(lung)
  } else {
    koch(t, lung, livello - 1)
    t.Left(math.Pi / 3.0)
    koch(t, lung, livello - 1)
    t.Right(math.Pi - math.Pi / 3.0)
    koch(t, lung, livello - 1)
    t.Left(math.Pi / 3.0)
    koch(t, lung, livello - 1)
  }
}

/* Questa funzione usa la tartaruga t per disegnare un fiocco di koch
   di livello dato, con segmenti di lunghezza lung */
func kochSnowflake(t *terrapin.Terrapin, lung float64, livello int) {
  koch(t, lung, livello)
  t.Right(2.0 * math.Pi / 3.0)
  koch(t, lung, livello)
  t.Right(2.0 * math.Pi / 3.0)
  koch(t, lung, livello)
  t.Right(2.0 * math.Pi / 3.0)
}

func curvaKoch(w http.ResponseWriter, r *http.Request) {
  liv, _ := strconv.Atoi(r.FormValue("liv"))
  segm, _ := strconv.ParseFloat(r.FormValue("segm"), 64)
  image := image.NewRGBA(image.Rect(0, 0, 800, 500))
  t := terrapin.NewTerrapin(image, terrapin.Position{250.0, 420.0})
  kochSnowflake(t, segm, liv)
  png.Encode(w, image)
}


func natalePage(w http.ResponseWriter, r *http.Request) {
  w.Write([]byte(`
          <!doctype html>
            <title>Natale</title>
            <h1>Natale</h1>

            <p>Buon Natale con il fiocco di Koch!

            <p><img src="http://localhost:3000/curvakoch.png?liv=` + r.FormValue("liv") + "&segm=" + r.FormValue("segm") +`">`))
}


func formPage(w http.ResponseWriter, r *http.Request) {
  w.Write([]byte(`
          <!doctype html>
            <title>Form</title>
            <h1>Valori da usare per il fiocco</h1>

		<form action=/natale>
			<label for="livello">Livello:</label><br><input type="text" id="liv" name="liv"><br>
			<label for="segmento">Lunghezza segmento:</label><br><input type="text" id="segm" name="segm">
			<br><input type="submit" value="Submit">
		</form>`))
}

func main() {
  http.HandleFunc("/pippo", pippoPage)
  http.HandleFunc("/pluto", plutoPage)
  http.HandleFunc("/nostraimmagine.png", imgPage)
  http.HandleFunc("/natale", natalePage)
  http.HandleFunc("/curvakoch.png", curvaKoch)
  http.HandleFunc("/form", formPage)
  fmt.Println("Listening on http://localhost:3000/")
  http.ListenAndServe(":3000", nil)
}
