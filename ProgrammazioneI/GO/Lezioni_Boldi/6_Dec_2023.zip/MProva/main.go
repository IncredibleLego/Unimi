package main

import (
  "github.com/boldip/geom/mpoint"
  "fmt"
)

func main() {
  var p1, p2 mpoint.Point

  p1 = mpoint.NewPoint(3, 2)
  p2 = mpoint.NewPoint(5, 5)

  dist := p1.Dist(p2)
  fmt.Println("La distanza fra", p1, "e", p2, "è", dist)

  pm := p1.Median(p2)
  fmt.Println("Il loro punto medio è", pm)

}
