package mpoint

type Point struct {
  x, y float64
}
