package mpoint

func (p Point) X() float64 {
  return p.x
}

func (p Point) Y() float64 {
  return p.y
}
