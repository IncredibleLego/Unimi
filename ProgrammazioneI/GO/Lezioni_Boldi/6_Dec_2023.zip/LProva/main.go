package main

import (
  "github.com/boldip/geom/mline"
  "github.com/boldip/geom/mpoint"
  "fmt"
)

func main() {
  p := mpoint.NewPoint(2, 3)
  r := mline.NewLine(1, 1)   // y = x + 1
  fmt.Println("Il punto", p, "appartiene alla retta", r, "? ", r.Belongs(p))
  p2 := mpoint.NewPoint(5, 5)

  fmt.Println("Il punto", p2, "dista dalla retta", r, "di", r.Dist(p2))
}
