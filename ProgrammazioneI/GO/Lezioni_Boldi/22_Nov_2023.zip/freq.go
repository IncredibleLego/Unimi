package main

import (
  "fmt"
  "bufio"
  "os"
  "strings"
)

func readAndComputeFreq() map[string]int {
  var result map[string]int   

  result = make(map[string]int)

  scanner := bufio.NewScanner(os.Stdin)
  scanner.Split(bufio.ScanWords)

  scanner.Scan()
  for  scanner.Scan() {
    word := strings.ToLower(scanner.Text())
    result[word]++
  }
  return result
}

func main() {
  m := readAndComputeFreq()
  for k, v := range m {
    fmt.Printf("%20s\t%5d\n", k, v)
  }
}
