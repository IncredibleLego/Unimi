package main

import (
  "fmt"
  "bufio"
  "os"
  "strings"
  "math/rand"
  "time"
)

func readAndComputeFollow() map[string][]string {
  var result map[string][]string   // Associa alla stringa x la slice con tutte le stringhe che seguono x

  result = make(map[string][]string)

  scanner := bufio.NewScanner(os.Stdin)
  scanner.Split(bufio.ScanWords)

  scanner.Scan()
  prev := strings.ToLower(scanner.Text())
  for  scanner.Scan() {
    word := strings.ToLower(scanner.Text())
    result[prev] = append(result[prev], word)
    prev = word
  }
  return result
}

func generate(inizio string, next map[string][]string, r *rand.Rand) {
    for  {
      fmt.Print(inizio + " ")
      x := next[inizio]
      if len(x) == 0 {
        inizio = "io"
      } else {
        inizio = x[r.Intn(len(x))]
      }
    }
}

func main() {
  r := rand.New(rand.NewSource(time.Now().UnixNano()))
  m := readAndComputeFollow()
  generate("io", m, r)
  //for k, v := range m {
  //  fmt.Printf("%20s\t%v\n", k, v)
  //}
}
