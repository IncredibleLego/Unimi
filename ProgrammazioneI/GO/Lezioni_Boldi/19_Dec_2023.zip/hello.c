#include <stdio.h>

int main() {
    int n, i;
    printf("Quante volte, padrone? ");
    scanf("%d", &n);
    for (i=0; i<n; i++)
        printf("Ciao\n");
}
