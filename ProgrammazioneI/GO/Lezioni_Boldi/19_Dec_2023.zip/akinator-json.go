package main

import (
  "encoding/json"
  "bufio"
  "os"
  "io"
  "fmt"
  "strings"
)

type Node struct {
  Question string
  Yes, No *Node
}

func initialize() *Node {
  root := new(Node)
  yesAnswer := new(Node)
  noAnswer := new(Node)
  *root = Node{"E' una ragazza?", yesAnswer, noAnswer}
  *yesAnswer = Node{"Giorgia Meloni", nil, nil}
  *noAnswer = Node{"Matteo Salvini", nil, nil}
  return root
}

/* Legge da standard input una risposta (yes or no) e restituisce o 'y' o 'n' */
func yes_no() rune {
  var answer string
  for {
    fmt.Scan(&answer)
    answer = strings.ToLower(answer)
    if len(answer) == 0 || answer[0] != 'y' && answer[0] != 'n' {
      fmt.Printf("\tPlease answer y(es) or n(o)... ")
    } else {
      return rune(answer[0])
    }
  }
}

func ask(root *Node) *Node {
  curr := root
  for curr.Yes != nil {
    fmt.Printf("%s [y/n] ", curr.Question)
    yn := yes_no()
    if yn == 'y' {
      curr = curr.Yes
    } else {
      curr = curr.No
    }
  }
  return curr
}

func play(root *Node) {
  scanner := bufio.NewScanner(os.Stdin)

  leaf := ask(root)
  fmt.Printf("Per me stai pensando a %s\n", leaf.Question)
  fmt.Printf("Ho ragione? ")
  yn := yes_no()
  if yn == 'y' {
    fmt.Println("*** Sono stato bravissimo!")
  } else {
    fmt.Printf("A chi stavi pensando? ")
    scanner.Scan()
    rightAnswer := scanner.Text()
    fmt.Printf("Dimmi una domanda in cui la risposta per %s sia sì e per %s sia no: ", leaf.Question, rightAnswer)
    scanner.Scan()
    question := scanner.Text()

    nodeYes := new(Node)
    nodeNo := new(Node)
    *nodeYes = Node{leaf.Question, nil, nil}
    *nodeNo = Node{rightAnswer, nil, nil}
    *leaf = Node{question, nodeYes, nodeNo}
  }
}

func readTree(fileR *os.File) *Node {
  var root *Node
  bytes, _ := io.ReadAll(fileR)
  json.Unmarshal(bytes, &root)
  return root
}

func writeTree(root *Node, fileW *os.File) {
  bytes, _ := json.Marshal(root)
  fileW.Write(bytes)
}

func main() {
  var root *Node

  filename := os.Args[1]
  fileR, err := os.Open(filename)
  defer fileR.Close()
  if err != nil {
    root = initialize()
  } else {
    root = readTree(fileR)
  }

  for {
    play(root)
    fmt.Println("Vuoi giocare ancora? [y/n] ")
    yn := yes_no()
    if yn == 'n' {
      break
    }
  }
  fileW, err := os.Create(filename)
  defer fileW.Close()
  if err != nil {
    fmt.Println("Errore nella scrittura del file")
  } else {
    writeTree(root, fileW)
  }
}
