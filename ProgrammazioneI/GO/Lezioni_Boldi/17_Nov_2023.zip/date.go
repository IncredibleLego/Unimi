package main

import (
  "os"
  "strconv"
  "fmt"
  "math/rand"
  "time"
)

type data struct {
  g, m, a int
}

// Genera e restituisce una data con anno compreso fra anno1 e anno2
// e usa r per generare numeri casuali
func generaData(anno1, anno2 int, r *rand.Rand) data {
  var d data
  lungMese := []int{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}

  d.a = r.Intn(anno2 - anno1 + 1) + anno1
  if d.a % 4 == 0 && (d.a % 100 != 0 || d.a % 400 == 0) {
    lungMese[1] = 29
  }
  d.m = r.Intn(12) + 1
  d.g = r.Intn(lungMese[d.m - 1]) + 1
  return d
}

func stampaData(d data) {
  fmt.Print(d.g, "/", d.m, "/", d.a, "\n")
}

func main() {
  var n, anno1, anno2 int

  n, _ = strconv.Atoi(os.Args[1])
  anno1, _ = strconv.Atoi(os.Args[2])
  anno2, _ = strconv.Atoi(os.Args[3])

  r := rand.New(rand.NewSource(time.Now().UnixNano()))   // Crea un generatore

  for i := 0; i < n; i++ {
    stampaData(generaData(anno1, anno2, r))
  }
}
