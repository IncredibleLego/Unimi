package main

import (
  "fmt"
)

type Esame struct {
  nome string
  proped []string
}

/* Dato un cds elimina l'esame di nome dato e lo toglie anche da tutte le propedeuticità,
   creando un nuovo cds */
func eliminaEsame(cds []Esame, nome string) []Esame {
  var res []Esame
  for _, esame := range cds {
    if esame.nome == nome {
      continue
    }
    // Creo un nuovo esame con lo stesso nome e le stesse propedeuticità
    // MA eliminando da esse nome
    var nuovoEsame Esame
    nuovoEsame.nome = esame.nome
    for _, prop := range esame.proped {
      if prop != nome {
        nuovoEsame.proped = append(nuovoEsame.proped, prop)
      }
    }
    res = append(res, nuovoEsame)
  }
  return res
}

func ordiniPossibili(cds []Esame) []string {
  var res []string
  if len(cds) == 0 {
    return []string{""}
  }
  for _, esame := range cds {
    if len(esame.proped) > 0 {
      continue
    }
    nuovoCds := eliminaEsame(cds, esame.nome)
    ordini := ordiniPossibili(nuovoCds)
    for _, ordine := range ordini {
      if ordine != "" {
        res = append(res, esame.nome + "," + ordine)
      } else {
        res = append(res, esame.nome + ordine)
      }
    }
  }
  return res
}


func main() {
  var cds []Esame
  cds = []Esame{
    Esame{"A", []string{}},
    Esame{"B", []string{}},
    Esame{"C", []string{"A"}},
    Esame{"D", []string{"C","B"}},
    Esame{"E", []string{"C","D"}},
  }

  //fmt.Println(eliminaEsame(cds, "A"))

  fmt.Println(ordiniPossibili(cds))
}
