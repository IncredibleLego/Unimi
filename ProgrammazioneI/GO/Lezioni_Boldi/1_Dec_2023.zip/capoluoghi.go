package main

import (
  "fmt"
  "os"
  "bufio"
  "strings"
  "strconv"
)

type Capoluogo struct {
  citta, sigla, regione string
  superficie int
}

func main() {
  var capi []Capoluogo
  var sigla2capo map[string]Capoluogo
  var sigleDaStampare []string

  sigleDaStampare = os.Args[1:]
  sigla2capo = make(map[string]Capoluogo)

  scanner := bufio.NewScanner(os.Stdin)

  // Saltare la riga di intestazione
  scanner.Scan()
  scanner.Text()

  for scanner.Scan() {
    riga := scanner.Text()
    pezzi := strings.Split(riga, ",")
    var cap Capoluogo
    cap.citta = pezzi[0]
    cap.sigla = pezzi[1]
    cap.regione = pezzi[2]
    cap.superficie, _ = strconv.Atoi(pezzi[4])
    capi = append(capi, cap)
    sigla2capo[cap.sigla] = cap
  }

  for _, sigla := range sigleDaStampare {
    fmt.Println(sigla2capo[sigla])
  }

}
