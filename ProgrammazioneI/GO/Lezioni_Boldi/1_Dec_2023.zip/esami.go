package main

import (
  "fmt"
  "strings"
)

type Esame struct {
  nome string
  proped []string
}

func tuttiGliOrdiniPossibili(cds []Esame) []string {
  if len(cds) == 0 {
    return []string{""}
  }
  var res []string
  for i, primo := range cds {
    // Creo una copia di cds che NON contiene l'i-esimo elemento
    // Nel programma degli anagrammi facevo s[:i] + s[i+1:]
    var copia []Esame
    for j := 0; j < len(cds); j++ {
      if j != i {
        copia = append(copia, cds[j])
      }
    }
    // Chiamata ricorsiva
    t := tuttiGliOrdiniPossibili(copia)
    // Aggiungo tutti i risultati ottenuti dalla chiamata ricorsiva
    // mettendo a ciascuno in testa primo
    for _, ordine := range t {
      if ordine != "" {
        res = append(res, primo.nome + "," + ordine)
      } else {
        res = append(res, primo.nome + ordine)
      }
    }
  }
  return res
}

/* Controlla se ordine (una possibile sequenza di esami) rispetta le
   propedeuticità previste da cds */
func propedeuticitaOk(ordine []string, cds []Esame) bool {
  for i := 0; i < len(ordine); i++ {
    esame := ordine[i]
    // Cerco dentro cds un esame di nome Esame
    var x Esame
    for _, x = range cds {
      if x.nome == esame {
        break
      }
    }
    // Ho trovato l'esame e si chiama x
    for _, prop := range x.proped {
      var j int
      // Cerco l'esame di nome prop fra quelli sostenuti prima dell'indice i
      for j = 0; j < i; j++ {
        if ordine[j] == prop {
          break
        }
      }
      // Se non l'ho trovato
      if !(j < i) {
        return false
      }
    }
  }
  return true
}

func ordiniPossibili(cds []Esame) []string {
  var res []string
  tutti := tuttiGliOrdiniPossibili(cds)
  for _, ordine := range tutti {
    // Controllo che ordine rispetti le propedeuticità
    esami := strings.Split(ordine, ",")   // Esami sostenuti in un certo ordine
    if propedeuticitaOk(esami, cds) {
      res = append(res, ordine)
    }
  }
  return res
}

func main() {
  var cds []Esame
  cds = []Esame{
    Esame{"A", []string{}},
    Esame{"B", []string{}},
    Esame{"C", []string{"A"}},
    Esame{"D", []string{"C","B"}},
    Esame{"E", []string{"C","D"}},
  }

  //fmt.Println(propedeuticitaOk([]string{"A", "B", "C", "E", "D"}, cds))

  fmt.Println(ordiniPossibili(cds))
}
