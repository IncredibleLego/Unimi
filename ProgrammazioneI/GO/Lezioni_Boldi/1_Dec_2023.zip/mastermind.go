package main

import (	
	"fmt"
	"math/rand"
	"time"
	"os"
	"strconv"
)

type Try struct {
	attempt string
	rr, rw int
}

func min(x,y int) int {
	if x < y {
		return x
	}
	return y
}

func compare(attempt string, target string) (rr int, rw int) {
	var counta, countt map[byte]int
	counta = make(map[byte]int)
	countt = make(map[byte]int)

	for i := 0; i < len(attempt); i++ {
		if attempt[i] == target[i] {
			rr++
		} else {
			counta[attempt[i]]++
			countt[target[i]]++
		}
	}
	for k, v := range counta {
		rw += min(v, countt[k])
	}
	return
}

func canBeTarget(target string, tries []Try) bool {
	for _, try := range tries {
		rr, rw := compare(try.attempt, target)
		if rr != try.rr || rw != try.rw {
			return false
		}
	}
	return true
}

func generateAll(length int) (res []string) {
	if length == 0 {	
		return []string{""}
	}
	t := generateAll(length - 1)	
	for _, x := range t {
		for i := 'A'; i <= 'F'; i++ {	
			res = append(res, string(rune(i)) + x)		
		}
	}
	return
}

func generatePossibleTarget(length int, tries []Try, r *rand.Rand) (target string, ok bool) {
	possibleTargets := []string{}
	t := generateAll(length)
	for _, x := range t {
		if canBeTarget(x, tries) {
			possibleTargets = append(possibleTargets, x)
		}
	}
	if len(possibleTargets) == 0 {
		return
	}
	target = possibleTargets[r.Intn(len(possibleTargets))]
	ok = true
	return
}

func main() {
	var tries []Try
	var count, rr, rw int

	length, _ := strconv.Atoi(os.Args[1])
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	for {
		count++
		target, ok := generatePossibleTarget(length, tries, r)
		if !ok {
			fmt.Println("IMPOSSIBILE!")
			break
		}
		fmt.Printf("%4d. %s\tGiusti al posto giusto, giusti al posto sbagliato? ", count, target)
		fmt.Scan(&rr, &rw)
		if rr == length {
			fmt.Println("Ho vinto!")
			break
		}
		tries = append(tries, Try{target, rr, rw})
	}
}


