package main

import (
  "fmt"
  "github.com/boldip/geom/point"
)

func main() {
  var p1, p2 point.Point
  p1 = point.NewPoint(3, 2)
  p2 = point.NewPoint(5, 7)
  fmt.Printf("Distanza fra il punto %s e il punto %s è %f\n",
    point.Str(p1),
    point.Str(p2),
    point.Dist(p1, p2))

  pm := point.Median(p1, p2)
  fmt.Printf("Il loro punto medio è %s\n", point.Str(pm))
}
