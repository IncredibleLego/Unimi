/*
  ./croce 30elode
  3     3
   0   0
    e e
     l
    o o
   d   d
  e     e
*/
package main

import (
  "fmt"
  "os"
)

func main() {
  s := os.Args[1]
  n := len(s)

  for y := 0; y < n; y++ {
    for x := 0; x < n; x++ {
      /*****/
      if x == y || x == n-1-y {
        fmt.Printf("%c", s[y])
      } else {
        fmt.Print(" ")
      }
    }
    fmt.Println()
  }
}
