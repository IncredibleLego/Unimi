package main

/*
  Converte le righe come in questo esempio:

          ci sono *** cani e **** gatti

          ci sono 3 cani e 4 gatti
*/
import (
  "bufio"
  "fmt"
  "os"
  "strconv"
)

// Crea una stringa identica a s a parte il fatto che le sequenze di * vengono convertite in un numero (la loro lunghezza)
func converti(s string) string {
    var t string
    var j int

    for i := 0; i < len(s); i++ {
      if s[i] != '*' {
        t += string(s[i])
      } else {
        for j = i; j < len(s) && s[j] == '*'; j++ {}
        // s[i:j] contiene solo asterischi (j escluso!)
        // la sequenza è lunga j-i
        t += strconv.Itoa(j-i)
        i = j - 1
      }
    }
    return t
}

func main() {
  scanner := bufio.NewScanner(os.Stdin)
  for scanner.Scan() {
    riga := scanner.Text()
    rigaConvertita := converti(riga)
    fmt.Println(rigaConvertita)
  }
}
