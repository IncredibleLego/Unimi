package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Split(bufio.ScanWords)

	scanner.Scan()
	s := scanner.Text()
	fmt.Println(s)
	scanner.Scan()
	t := scanner.Text()
	fmt.Println(t)

}
