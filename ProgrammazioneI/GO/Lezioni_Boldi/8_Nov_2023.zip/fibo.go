// F[0]=1
// F[1]=1
// F[n]=F[n-1]+F[n-2]  per ogni n>1

package main

import "fmt"

func main() {
  var n, last1, last2, curr int
  fmt.Scan(&n)
  last1 = 1
  last2 = 1
  for i:=0; i < n; i++ {
    if i < 2 {
      curr = 1
    } else {
      curr = last1 + last2
    }
    for j:=0; j < curr; j++ {
      fmt.Print("*")
    }
    fmt.Println()
    last1, last2 = last2, curr
  }
}
