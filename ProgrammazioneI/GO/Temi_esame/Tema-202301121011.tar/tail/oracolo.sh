tail -n $1 $2
